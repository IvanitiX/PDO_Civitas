# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "CivitasJuego"

#EXAMEN-inicio
module Civitas
  class TestExamen
    def self.main
      @diario = Diario.instance
      @jugadores = Array.new
      @jugadores << "Ivan"
      @jugadores << "Mumo"
      
      @juego = CivitasJuego.new(@jugadores)
      
      consejero1 = PersonalDeApoyo::Consejero.crearConsejeroSinAsociar("Cascos", 0, @juego)
      consejero2 = PersonalDeApoyo::Consejero.crearConsejeroSinAsociar("Arcadia", 0, @juego)
      
      @juego.actualizarInfo
      
      consejero1.aconsejar_jugador(@juego.getJugadorActual)
      @juego.indiceJugadorActual = @juego.indiceJugadorActual + 1
      consejero2.aconsejar_jugador(@juego.getJugadorActual)
      
      while(@diario.eventos_pendientes)
        puts @diario.leer_evento
      end
      
    end
  end
  Civitas::TestExamen.main
end

#EXAMEN-fin
