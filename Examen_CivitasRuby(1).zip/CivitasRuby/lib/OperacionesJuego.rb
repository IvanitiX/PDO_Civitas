# encoding:utf-8

#Author: Miguel Muñoz Molina
#Author: Iván Valero Rodríguez

module Civitas  
  module OperacionesJuego    
    AVANZAR = :avanzar    
    COMPRAR = :comprar    
    GESTIONAR = :gestionar    
    SALIR_CARCEL = :salir_carcel    
    PASAR_TURNO = :pasar_turno  
    end
  end