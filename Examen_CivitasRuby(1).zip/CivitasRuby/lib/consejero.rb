# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

#EXAMEN-inicio
require_relative "CivitasJuego"
require_relative "diario"
require_relative "Jugador"


module PersonalDeApoyo

  class Consejero
    @@num_consejeros = 0
    @@juego
    attr_accessor :nombre
    attr_writer :num_consejeros
    private_class_method :new
    
    def initialize(jugador,nombre,umbral_compra,partida)
      @@juego = partida
      @jugador_asociado = jugador
      @nombre = nombre
      @umbral_de_compra_aconsejado = umbral_compra
      @@num_consejeros = @@num_consejeros + 1    
      @diario = Civitas::Diario.instance
    end
    
    def self.crearConsejeroSinAsociar(nombre,umbral,partida)
      new(nil,nombre,umbral,partida)
    end
    
    def self.crearConsejeroAsociado(jugador,umbral,partida)
      nombre_jugador = jugador.nombre
      new(jugador, "Consejero de #{nombre_jugador}",umbral,partida)
    end
    
    def aconsejar_jugador(un_jugador)
      if(un_jugador == @@juego.getJugadorActual)
        propiedades_jugador = un_jugador.propiedades
        numCasasTotal = 0
        for p in propiedades_jugador do
          numCasasTotal = numCasasTotal + p.numCasas
        end
        if (numCasasTotal <= @umbral_de_compra_aconsejado)
          @diario.ocurre_evento("#{@nombre} aconseja que se compre la propiedad")
        else
          @diario.ocurre_evento("#{@nombre} NO aconseja que se compre la propiedad")
        end
      end
    end
    
    def self.num_consejeros
      return @@num_consejeros
    end
    
    
  end
end
#EXAMEN-fin